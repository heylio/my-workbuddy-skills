# my-workbuddy-skills

WorkBuddy Skills for the flower shop management system.

This bundle contains project-specific skills for:
- `frontend-design`: build practical, responsive frontend pages.
- `ui-ux-pro-max`: project adapter for a consistent UI/UX design system; upstream source is linked, not copied.
- `prototype-design`: turn the PRD into page flows and prototype specifications.
- `code-review`: review business correctness, security, data consistency, and regression risks.
- `testing`: plan and run unit, integration, API, and end-to-end tests.

## Install
Import the ZIP through WorkBuddy's supported skill upload/import flow, or copy each folder under `skills/` into the skills directory supported by your WorkBuddy environment. Check WorkBuddy's current documentation for the exact web UI import steps.

## Business rules captured from the project discussion
- Funds management separately records owner investment, personal withdrawals, loans, and repayments. These must not be mixed into operating revenue or operating expenses.
- First-release reports include operating revenue statistics, operating expense statistics, and product estimates.
- The exact formula for “product estimates” remains a business rule to confirm; do not invent it.
- Skills are project-specific guidance, not a claim that the source repositories' full codebases have been copied.

## Sources and licensing
See `sources.md`. The original UI UX Pro Max project is linked as an upstream dependency/reference; this repository does not redistribute its full source code.

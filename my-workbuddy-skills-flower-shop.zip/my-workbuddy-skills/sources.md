# Sources and licensing notes

| Skill | Source / provenance | Notes |
|---|---|---|
| frontend-design | Project-specific skill written for `heylio/my-workbuddy-skills` | Original guidance authored for this repository. |
| ui-ux-pro-max | https://github.com/nextlevelbuilder/ui-ux-pro-max-skill | Upstream project declares MIT; confirm the current upstream `LICENSE` before redistributing upstream files. This bundle contains only a project-specific adapter and link, not the upstream code/data. |
| prototype-design | Project-specific skill written for `heylio/my-workbuddy-skills` | Based on the flower-shop PRD context in the conversation; unknown business rules are explicitly marked for confirmation. |
| code-review | Project-specific skill written for `heylio/my-workbuddy-skills` | Original guidance authored for this repository. |
| testing | Project-specific skill written for `heylio/my-workbuddy-skills` | Original guidance authored for this repository. |

Do not copy third-party skill repositories into this repository without checking their license, attribution requirements, and WorkBuddy compatibility.
